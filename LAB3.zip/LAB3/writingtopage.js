/* This is the first JavaScript code that I have written
Written by: Phung Hoang
Written on: 11/1/2022
*/

document.write('Good Afternoon Phung Hoang');
document.write('<h1>Would you like some cupcakes?</h1>');

//The end of my first program